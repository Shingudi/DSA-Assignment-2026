# Short Defense Guide

## Question 1

**Why use assetTag?**
It is the unique identifier for every asset.

**Why use a map?**
A map makes it easy to find an asset using its assetTag.

**Why REST?**
REST uses HTTP methods such as GET, POST, PUT and DELETE to communicate between the client and server.

**What does GET do?**
It reads data.

**What does POST do?**
It creates/adds data.

**What does PUT do?**
It updates data.

**What does DELETE do?**
It removes data.

## Question 2

**What is gRPC?**
It is a framework for calling functions on another computer/server.

**What is Protocol Buffers?**
It is the contract used to define the messages and services.

**What is simple RPC?**
One request is sent and one response is returned.

**What is client streaming?**
The client sends multiple messages and the server returns one response.

**What is server streaming?**
The client sends one request and the server returns multiple messages.

**Why is create_users client streaming?**
The requirement says several users must be sent from the client before one confirmation is returned.

**Why is list_available_properties server streaming?**
The server can send several available properties one by one.
