# DSA612S Assignment 1 - Beginner Implementation

This project contains both questions from the assignment.

## Important

The assignment itself says that AI-generated code should not be submitted as your own and that the group must be able to defend the solution. Use this project as a learning/reference starting point. Read it, test it, change it, and make sure you understand every part before submitting.

The assignment requires:
- Question 1: RESTful Library and Resource Management System - 50 marks.
- Question 2: gRPC Rental Accommodation System - 50 marks.

The assignment deadline shown in the brief is 14 September 2026 at 23:59.
