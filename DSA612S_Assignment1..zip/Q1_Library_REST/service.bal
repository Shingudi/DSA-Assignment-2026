import ballerina/http;
import ballerina/io;

type Component record {|
    string compId;
    string name;
    string description;
|};

type Schedule record {|
    string scheduleId;
    string type;
    string dueDate;
    string description;
|};

type Task record {|
    string taskId;
    string description;
|};

type WorkOrder record {|
    string orderId;
    string status;
    string description;
    Task[] tasks;
|};

type Asset record {|
    string assetTag;
    string name;
    string description;
    string institution;
    string site;
    string dateAcquired;
    string status;
    Component[] components = [];
    Schedule[] schedules = [];
    WorkOrder[] workOrders = [];
|};

type Institution record {|
    string name;
    string[] sites;
|};

// Simple in-memory storage.
// The assetTag is used as the key, so every asset is unique.
map<Asset> assets = {
    "NUST-LIB-001": {
        assetTag: "NUST-LIB-001",
        name: "Library Laptop",
        description: "Laptop for library use",
        institution: "Namibia University of Science and Technology",
        site: "Main Campus",
        dateAcquired: "2025-02-10",
        status: "AVAILABLE"
    },
    "UNAM-LIB-001": {
        assetTag: "UNAM-LIB-001",
        name: "Study Room",
        description: "Small meeting and study room",
        institution: "University of Namibia",
        site: "Main Campus",
        dateAcquired: "2024-05-12",
        status: "AVAILABLE"
    }
};

map<Institution> institutions = {
    "Namibia University of Science and Technology": {
        name: "Namibia University of Science and Technology",
        sites: ["Main Campus", "Innovation Lab"]
    },
    "University of Namibia": {
        name: "University of Namibia",
        sites: ["Main Campus"]
    }
};

service /api on new http:Listener(9090) {

    // Get all assets.
    resource function get assets() returns Asset[] {
        Asset[] result = [];
        foreach Asset asset in assets {
            result.push(asset);
        }
        return result;
    }

    // Get one asset.
    resource function get assets/[string tag]() returns Asset|http:NotFound {
        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        return asset;
    }

    // Add an asset.
    resource function post assets(Asset asset) returns Asset|http:Conflict {
        if assets.hasKey(asset.assetTag) {
            return http:CONFLICT;
        }

        assets[asset.assetTag] = asset;
        return asset;
    }

    // Update an asset.
    resource function put assets/[string tag](Asset asset) returns Asset|http:NotFound {
        if !assets.hasKey(tag) {
            return http:NOT_FOUND;
        }

        assets[tag] = asset;
        return asset;
    }

    // Delete an asset.
    resource function delete assets/[string tag]() returns string|http:NotFound {
        if !assets.hasKey(tag) {
            return http:NOT_FOUND;
        }

        _ = assets.remove(tag);
        return "Asset deleted";
    }

    // Find assets by institution.
    resource function get assets/institution(string name) returns Asset[] {
        Asset[] result = [];

        foreach Asset asset in assets {
            if asset.institution == name {
                result.push(asset);
            }
        }

        return result;
    }

    // Find assets by site.
    resource function get assets/site(string name) returns Asset[] {
        Asset[] result = [];

        foreach Asset asset in assets {
            if asset.site == name {
                result.push(asset);
            }
        }

        return result;
    }

    // Show assets that have a maintenance date before the supplied date.
    // Example: /api/assets/overdue?today=2026-09-12
    resource function get assets/overdue(string today) returns Asset[] {
        Asset[] result = [];

        foreach Asset asset in assets {
            foreach Schedule schedule in asset.schedules {
                if schedule.type == "MAINTENANCE" && schedule.dueDate < today {
                    result.push(asset);
                    break;
                }
            }
        }

        return result;
    }

    // Add a component.
    resource function post assets/[string tag]/components(Component component)
        returns Asset|http:NotFound {

        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        asset.components.push(component);
        assets[tag] = asset;

        return asset;
    }

    // Remove a component.
    resource function delete assets/[string tag]/components/[string compId]()
        returns Asset|http:NotFound {

        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        Component[] newComponents = [];

        foreach Component component in asset.components {
            if component.compId != compId {
                newComponents.push(component);
            }
        }

        asset.components = newComponents;
        assets[tag] = asset;

        return asset;
    }

    // Add a servicing/booking schedule.
    resource function post assets/[string tag]/schedules(Schedule schedule)
        returns Asset|http:NotFound {

        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        asset.schedules.push(schedule);
        assets[tag] = asset;

        return asset;
    }

    // Remove a schedule.
    resource function delete assets/[string tag]/schedules/[string scheduleId]()
        returns Asset|http:NotFound {

        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        Schedule[] newSchedules = [];

        foreach Schedule schedule in asset.schedules {
            if schedule.scheduleId != scheduleId {
                newSchedules.push(schedule);
            }
        }

        asset.schedules = newSchedules;
        assets[tag] = asset;

        return asset;
    }

    // Add a work order.
    resource function post assets/[string tag]/workorders(WorkOrder order)
        returns Asset|http:NotFound {

        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        asset.workOrders.push(order);
        assets[tag] = asset;

        return asset;
    }

    // Update the status of a work order.
    resource function put assets/[string tag]/workorders/[string orderId](WorkOrder order)
        returns Asset|http:NotFound {

        Asset? asset = assets[tag];

        if asset is () {
            return http:NOT_FOUND;
        }

        WorkOrder[] newOrders = [];

        foreach WorkOrder oldOrder in asset.workOrders {
            if oldOrder.orderId == orderId {
                newOrders.push(order);
            } else {
                newOrders.push(oldOrder);
            }
        }

        asset.workOrders = newOrders;
        assets[tag] = asset;

        return asset;
    }

    // Simple loan operation.
    resource function post assets/[string tag]/loan() returns Asset|string {
        Asset? asset = assets[tag];

        if asset is () {
            return "Asset not found";
        }

        if asset.status != "AVAILABLE" {
            return "Asset is not available";
        }

        asset.status = "LOANED_OUT";
        assets[tag] = asset;

        return asset;
    }

    // Simple booking operation for a room or lab.
    resource function post assets/[string tag]/book() returns Asset|string {
        Asset? asset = assets[tag];

        if asset is () {
            return "Asset not found";
        }

        if asset.status != "AVAILABLE" {
            return "Resource is not available";
        }

        asset.status = "OCCUPIED";
        assets[tag] = asset;

        return asset;
    }

    // Institution management.
    resource function get institutions() returns Institution[] {
        Institution[] result = [];

        foreach Institution institution in institutions {
            result.push(institution);
        }

        return result;
    }

    resource function post institutions(Institution institution)
        returns Institution|http:Conflict {

        if institutions.hasKey(institution.name) {
            return http:CONFLICT;
        }

        institutions[institution.name] = institution;
        return institution;
    }

    resource function delete institutions/[string name]() returns string|http:NotFound {
        if !institutions.hasKey(name) {
            return http:NOT_FOUND;
        }

        _ = institutions.remove(name);
        return "Institution removed";
    }
}
