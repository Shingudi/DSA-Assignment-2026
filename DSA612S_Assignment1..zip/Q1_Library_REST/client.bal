import ballerina/http;
import ballerina/io;

type Component record {|
    string compId;
    string name;
    string description;
|};

type Schedule record {|
    string scheduleId;
    string type;
    string dueDate;
    string description;
|};

type Task record {|
    string taskId;
    string description;
|};

type WorkOrder record {|
    string orderId;
    string status;
    string description;
    Task[] tasks;
|};

type Asset record {|
    string assetTag;
    string name;
    string description;
    string institution;
    string site;
    string dateAcquired;
    string status;
    Component[] components = [];
    Schedule[] schedules = [];
    WorkOrder[] workOrders = [];
|};

public function main() returns error? {
    http:Client client = check new ("http://localhost:9090");

    io:println("1. ALL ASSETS");
    Asset[] allAssets = check client->/api/assets;
    io:println(allAssets);

    io:println("\n2. ONE ASSET");
    Asset one = check client->/api/assets/["NUST-LIB-001"];
    io:println(one);

    io:println("\n3. ADD ASSET");
    Asset newAsset = {
        assetTag: "NUST-LIB-002",
        name: "Library Laptop 2",
        description: "Second laptop",
        institution: "Namibia University of Science and Technology",
        site: "Main Campus",
        dateAcquired: "2026-01-15",
        status: "AVAILABLE"
    };
    Asset added = check client->/api/assets.post(newAsset);
    io:println(added);

    io:println("\n4. FILTER BY INSTITUTION");
    Asset[] filtered = check client->/api/assets/institution?name=
        "Namibia University of Science and Technology";
    io:println(filtered);

    io:println("\n5. LOAN ASSET");
    Asset loaned = check client->/api/assets/["NUST-LIB-002"]/loan.post();
    io:println(loaned);

    io:println("\n6. ADD SCHEDULE");
    Schedule schedule = {
        scheduleId: "SCH-001",
        type: "MAINTENANCE",
        dueDate: "2026-10-01",
        description: "Basic laptop check"
    };

    Asset scheduled = check client->/api/assets/["NUST-LIB-002"]/schedules.post(schedule);
    io:println(scheduled);

    io:println("\nClient finished.");
}
