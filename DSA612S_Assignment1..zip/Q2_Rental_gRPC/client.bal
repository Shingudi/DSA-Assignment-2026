import ballerina/grpc;
import ballerina/io;

public function main() returns error? {
    RentalServiceClient client = check new ("http://localhost:9091");

    io:println("1. ADD PROPERTY");

    PropertyResponse added = check client->add_property({
        property_name: "Sea View Apartment",
        location: "Swakopmund",
        property_type: "Apartment",
        price_per_night: 900,
        status: "AVAILABLE",
        host_id: "H1"
    });

    io:println(added);

    io:println("\n2. CREATE USERS - CLIENT STREAMING");

    CreateUsersStreamingClient userStream = check client->create_users();

    check userStream->sendUser({
        user_id: "H1",
        name: "John Host",
        role: "HOST"
    });

    check userStream->sendUser({
        user_id: "G1",
        name: "Mary Guest",
        role: "GUEST"
    });

    check userStream->complete();

    UserResponse users = check userStream->receiveUserResponse();
    io:println(users);

    io:println("\n3. LIST AVAILABLE PROPERTIES - SERVER STREAMING");

    stream<Property, grpc:Error?> result = check client->list_available_properties({
        location: "Swakopmund",
        max_price: 1000
    });

    check result.forEach(function(Property property) {
        io:println(property);
    });

    io:println("\n4. SEARCH PROPERTY");

    PropertyResponse found = check client->search_property({
        property_id: "P1"
    });

    io:println(found);

    io:println("\n5. UPDATE PROPERTY");

    PropertyResponse updated = check client->update_property({
        property_id: "P1",
        property_name: "Sea View Apartment",
        location: "Swakopmund",
        property_type: "Apartment",
        price_per_night: 1000,
        status: "AVAILABLE"
    });

    io:println(updated);

    io:println("\n6. BOOK PROPERTY");

    BookingResponse booking = check client->book_property({
        property_id: "P1",
        guest_id: "G1",
        check_in: "2026-10-01",
        check_out: "2026-10-03"
    });

    io:println(booking);

    io:println("\n7. CONFIRM BOOKING");

    BookingResponse confirmed = check client->confirm_booking({
        guest_id: "G1"
    });

    io:println(confirmed);

    io:println("\nClient finished.");
}
