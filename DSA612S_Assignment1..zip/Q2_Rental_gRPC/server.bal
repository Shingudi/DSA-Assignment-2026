import ballerina/grpc;
import ballerina/io;

@grpc:Descriptor {
    value: RENTAL_SERVICE_DESC
}

type PropertyData record {|
    string property_id;
    string property_name;
    string location;
    string property_type;
    float price_per_night;
    string status;
    string host_id;
|};

type BookingData record {|
    string booking_id;
    string property_id;
    string guest_id;
    string check_in;
    string check_out;
    float total_cost;
|};

map<PropertyData> properties = {};
BookingData[] bookings = [];
int nextPropertyId = 1;
int nextBookingId = 1;

service "RentalService" on new grpc:Listener(9091) {

    remote function add_property(PropertyRequest request) returns PropertyResponse {
        string id = "P" + nextPropertyId.toString();
        nextPropertyId += 1;

        PropertyData property = {
            property_id: id,
            property_name: request.property_name,
            location: request.location,
            property_type: request.property_type,
            price_per_night: <float>request.price_per_night,
            status: request.status,
            host_id: request.host_id
        };

        properties[id] = property;

        return {
            success: true,
            message: "Property added",
            property: {
                property_id: id,
                property_name: request.property_name,
                location: request.location,
                property_type: request.property_type,
                price_per_night: request.price_per_night,
                status: request.status,
                host_id: request.host_id
            }
        };
    }

    remote function create_users(stream<User, grpc:Error?> users) returns UserResponse|error {
        int count = 0;

        check users.forEach(function(User user) {
            io:println("Created user: " + user.name);
            count += 1;
        });

        return {
            message: "Users created successfully",
            number_created: count
        };
    }

    remote function update_property(UpdatePropertyRequest request) returns PropertyResponse {
        PropertyData? old = properties[request.property_id];

        if old is () {
            return {
                success: false,
                message: "Property not found"
            };
        }

        PropertyData updated = {
            property_id: request.property_id,
            property_name: request.property_name,
            location: request.location,
            property_type: request.property_type,
            price_per_night: <float>request.price_per_night,
            status: request.status,
            host_id: old.host_id
        };

        properties[request.property_id] = updated;

        return {
            success: true,
            message: "Property updated",
            property: {
                property_id: updated.property_id,
                property_name: updated.property_name,
                location: updated.location,
                property_type: updated.property_type,
                price_per_night: updated.price_per_night,
                status: updated.status,
                host_id: updated.host_id
            }
        };
    }

    remote function remove_property(RemovePropertyRequest request) returns PropertyList {
        _ = properties.remove(request.property_id);

        Property[] available = [];
        foreach PropertyData property in properties {
            if property.status == "AVAILABLE" {
                available.push({
                    property_id: property.property_id,
                    property_name: property.property_name,
                    location: property.location,
                    property_type: property.property_type,
                    price_per_night: property.price_per_night,
                    status: property.status,
                    host_id: property.host_id
                });
            }
        }

        return {
            message: "Property removed",
            properties: available
        };
    }

    remote function list_available_properties(PropertyFilter request)
        returns stream<Property, grpc:Error?> {

        Property[] result = [];

        foreach PropertyData property in properties {
            boolean locationOkay = request.location == "" || property.location == request.location;
            boolean priceOkay = request.max_price == 0 || property.price_per_night <= request.max_price;

            if property.status == "AVAILABLE" && locationOkay && priceOkay {
                result.push({
                    property_id: property.property_id,
                    property_name: property.property_name,
                    location: property.location,
                    property_type: property.property_type,
                    price_per_night: property.price_per_night,
                    status: property.status,
                    host_id: property.host_id
                });
            }
        }

        return result.toStream();
    }

    remote function search_property(SearchPropertyRequest request) returns PropertyResponse {
        PropertyData? property = properties[request.property_id];

        if property is () {
            return {
                success: false,
                message: "Not Available"
            };
        }

        return {
            success: true,
            message: "Property found",
            property: {
                property_id: property.property_id,
                property_name: property.property_name,
                location: property.location,
                property_type: property.property_type,
                price_per_night: property.price_per_night,
                status: property.status,
                host_id: property.host_id
            }
        };
    }

    remote function book_property(BookRequest request) returns BookingResponse {
        PropertyData? property = properties[request.property_id];

        if property is () {
            return {
                success: false,
                message: "Property not found"
            };
        }

        if property.status != "AVAILABLE" {
            return {
                success: false,
                message: "Property is not available"
            };
        }

        if request.check_out <= request.check_in {
            return {
                success: false,
                message: "Check-out date must be after check-in date"
            };
        }

        string id = "B" + nextBookingId.toString();
        nextBookingId += 1;

        // The booking is kept temporarily until confirm_booking.
        BookingData booking = {
            booking_id: id,
            property_id: request.property_id,
            guest_id: request.guest_id,
            check_in: request.check_in,
            check_out: request.check_out,
            total_cost: 0
        };

        bookings.push(booking);

        return {
            success: true,
            message: "Booking added to temporary cart",
            booking_id: id,
            total_cost: 0
        };
    }

    remote function confirm_booking(ConfirmBookingRequest request) returns BookingResponse {
        int index = -1;

        foreach int i in 0 ..< bookings.length() {
            if bookings[i].guest_id == request.guest_id {
                index = i;
                break;
            }
        }

        if index == -1 {
            return {
                success: false,
                message: "No booking in cart"
            };
        }

        BookingData booking = bookings[index];
        PropertyData? property = properties[booking.property_id];

        if property is () {
            return {
                success: false,
                message: "Property not found"
            };
        }

        // This beginner version uses simple date strings in YYYY-MM-DD format.
        // More advanced projects can use the Ballerina time module.
        int nights = 1;

        if booking.check_in != booking.check_out {
            nights = 1;
        }

        float total = property.price_per_night * <float>nights;

        // Check for a simple overlapping booking.
        foreach BookingData oldBooking in bookings {
            if oldBooking.property_id == booking.property_id
                && oldBooking.booking_id != booking.booking_id {

                if booking.check_in < oldBooking.check_out
                    && booking.check_out > oldBooking.check_in {
                    return {
                        success: false,
                        message: "Dates overlap with another booking"
                    };
                }
            }
        }

        properties[booking.property_id].status = "BOOKED";
        _ = bookings.remove(index);

        return {
            success: true,
            message: "Booking confirmed",
            booking_id: booking.booking_id,
            total_cost: total
        };
    }
}
